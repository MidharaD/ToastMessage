package com.example.toastmsg;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import java.io.Serializable;

import es.dmoral.toasty.Toasty;

//import es.dmoral.toasty.Toasty;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Hello world");
        actionBar.setSubtitle("Sub title");

        Button button = findViewById(R.id.button3);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Toast message", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, Act_two.class);
                startActivity(intent);
            }
        });
    }

    public void showMsg(View view) {
//        Toast toast = Toast.makeText(getApplicationContext(),"Hello this a toast",Toast.LENGTH_LONG);
//        toast.show();

        Intent intent = new Intent(MainActivity.this, Act_two.class);
        intent.putExtra("custom_layout", R.layout.custom_toast);
        startActivity(intent);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu) ;
        return super.onCreateOptionsMenu(menu);
    }

    public void showColorMsg(View view) {
       // Toasty.normal(this,"toast with icon",Toast.LENGTH_LONG, ContextCompat.getDrawable(this,R.drawable.ic_baseline_check_circle_24)).show();

        //Toasty.success(getApplicationContext(), "Success!", Toast.LENGTH_SHORT, true).show();

       // Toasty.info(getApplicationContext(), "Here is some info for you.", Toast.LENGTH_SHORT, true).show();

        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast,(ViewGroup) findViewById(R.id.toast_root));
        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.CENTER,0,0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);

        toast.show();
    }

    public void showIntent(View view) {
        Toast toast = Toast.makeText(getApplicationContext(),"Hello this a toast",Toast.LENGTH_LONG);
        toast.show();
        Intent intent = new Intent(MainActivity.this, Act_two.class);
        startActivity(intent);
    }

}