package com.example.toastmsg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import es.dmoral.toasty.Toasty;

public class Act_two extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_two);

//        String message = getIntent().getStringExtra("TOAST_MESSAGE");
//        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        int customLayoutId = getIntent().getIntExtra("custom_layout", 0);
        LayoutInflater inflater = getLayoutInflater();
        View customToastLayout = inflater.inflate(customLayoutId, (ViewGroup) findViewById(R.id.toast_root));
//        Toasty.custom(this, customToastLayout, Toast.LENGTH_SHORT).show();


        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.CENTER,0,0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(customToastLayout);

        toast.show();
    new Handler().postDelayed(new Runnable() {
        @Override
        public void run() {
            Intent intent = new Intent(Act_two.this,ActThree.class);
            startActivity(intent);
        }
    },5000);



    }
}